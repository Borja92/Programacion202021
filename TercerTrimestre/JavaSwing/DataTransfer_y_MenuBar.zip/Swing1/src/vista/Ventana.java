package vista;

import logica.Persona;
import logica.Personas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class Ventana {
    private JPanel pnlMain;
    private JButton btnAddPersona;
    private JButton btnBorrar;
    private JTable tblPersonas;
    private JButton btnNuevo;
    private Personas personas;
    private Ventana estaVentana;
    private JPopupMenu menuContextual;
    ModeloTablaPersonas modeloTablaPersonas;
    private JMenuBar menuPrincipal;

    public Ventana(Personas personas) {
        this.personas = personas;
        this.estaVentana = this;

        modeloTablaPersonas = new ModeloTablaPersonas(personas);
        tblPersonas.setModel(modeloTablaPersonas);

        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modeloTablaPersonas.removeRow(tblPersonas.getSelectedRow());
            }
        });

        btnNuevo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Map<String,Object> datos = new HashMap<>();
                DialogoNuevaPersona dialogo = new DialogoNuevaPersona(datos);
                if (datos.containsKey("persona"))
                    modeloTablaPersonas.addRow((Persona) datos.get("persona"));
                System.out.println(personas.getAll());
            }
        });

        configurarMenuContextual();
        configurarBarraMenu();

        tblPersonas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x = MouseInfo.getPointerInfo().getLocation().x;
                int y = MouseInfo.getPointerInfo().getLocation().y;
                if (e.getButton() == MouseEvent.BUTTON3) {
                    menuContextual.show(tblPersonas, 0, 0);
                    menuContextual.setLocation(x,y);
                }
            }
        });
    }

    private void configurarBarraMenu() {
        menuPrincipal = new JMenuBar();
        JMenu menu1 = new JMenu("Fichero");
        JMenuItem m1o1 = new JMenuItem("Opcion 1");
        m1o1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Opción1");
            }
        });
        JMenuItem m1o2 = new JMenuItem("Opcion 2");
        m1o2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Opcion2");
            }
        });
        menu1.add(m1o1);
        menu1.add(m1o2);
        menuPrincipal.add(menu1);

    }

    private void configurarMenuContextual() {
        menuContextual = new JPopupMenu();
        JMenuItem opcion1 = new JMenuItem("Borrar");
        JMenuItem opcion2 = new JMenuItem("Resetear edad");

        opcion1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modeloTablaPersonas.removeRow(tblPersonas.getSelectedRow());
            }
        });

        opcion2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Modificar");
            }
        });

        menuContextual.add(opcion1);
        menuContextual.add(opcion2);
    }

    public JPanel getPanel(){
        return pnlMain;
    }

    public void setMenuBar(JFrame frame) {
        frame.setJMenuBar(menuPrincipal);
    }

    public JMenuBar getMenuBar(){
        return menuPrincipal;
    }
}
