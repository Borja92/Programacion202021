package vista;

import logica.Persona;
import logica.Personas;

import javax.swing.*;
import java.awt.event.*;

public class Ventana {
    private JPanel pnlMain;
    private JButton btnAddPersona;
    private JButton btnMostrarPersonas;
    private JTextField txtNombre;
    private JSpinner spnEdad;
    private JTextField txtDni;
    private JTextField txtField;
    private JComboBox cmbCategoria;
    private JList lstPersonas;
    private JButton btnBorrar;
    private JComboBox cmbEjemplo;
    private Personas personas;

    public Ventana(Personas personas) {
        this.personas = personas;


        /*DefaultListModel<Persona> modeloLista = new DefaultListModel<>();
        for (Persona persona: personas.getAll())
            modeloLista.addElement(persona);*/
        ModeloListaPersonas modeloLista = new ModeloListaPersonas(personas);
        ListaRenderer listRenderer = new ListaRenderer();
        lstPersonas.setModel(modeloLista);
        lstPersonas.setCellRenderer(listRenderer);

        for (String categoria: Persona.getCategorias())
            cmbCategoria.addItem(categoria);

        btnAddPersona.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                int edad = (int) spnEdad.getValue();
                String dni = txtDni.getText();
                int categoria = Persona.getCategoriaByTag((String) cmbCategoria.getSelectedItem());
                Persona persona = new Persona(nombre, edad, dni, categoria);
                modeloLista.addElement(persona);
                System.out.println(personas.getAll());
            }
        });

        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int pos = lstPersonas.getSelectedIndex();
                if (pos > -1)
                    modeloLista.remove(pos);
                else
                    JOptionPane.showMessageDialog(btnBorrar,"Debe haber una persona seleccionada");
                System.out.println(personas.getAll());
            }
        });

        lstPersonas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    int confirmaBorrar = JOptionPane.showConfirmDialog(pnlMain,
                            "¿Desea borrar la fila?",
                            "Borrado de un elemento", JOptionPane.WARNING_MESSAGE);
                    if (confirmaBorrar == JOptionPane.OK_OPTION) {
                        modeloLista.remove(lstPersonas.getSelectedIndex());
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    lstPersonas.clearSelection();
                    lstPersonas.invalidate();
                }
            }
        });
    }

    public JPanel getPanel(){
        return pnlMain;
    }
}
