package vista;

import logica.Persona;
import logica.Personas;

import javax.swing.*;
import java.awt.event.*;

public class Ventana {
    private JPanel pnlMain;
    private JButton btnAddPersona;
    private JButton btnMostrarPersonas;
    private JTextField txtNombre;
    private JSpinner spnEdad;
    private JTextField txtDni;
    private JTextField txtField;
    private JComboBox cmbCategoria;
    private JComboBox cmbEjemplo;
    private Personas personas;

    public Ventana(Personas personas) {
        this.personas = personas;

        for (String categoria: Persona.getCategorias())
            cmbCategoria.addItem(categoria);

        btnAddPersona.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                int edad = (int) spnEdad.getValue();
                String dni = txtDni.getText();
                int categoria = Persona.getCategoriaByTag((String) cmbCategoria.getSelectedItem());
                Persona persona = new Persona(nombre, edad, dni, categoria);
                personas.add(persona);

            }
        });

        btnMostrarPersonas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(personas.getAll());
            }
        });

        ///////

        cmbEjemplo.addItem(new Persona("A",1,"A",1));
        cmbEjemplo.addItem(new Persona("B",2,"B",2));
    }

    public JPanel getPanel(){
        return pnlMain;
    }
}
