package logica;

import java.util.ArrayList;
import java.util.List;

public class Personas {
    private List<Persona> personas;

    public Personas(){
        personas = new ArrayList<>();
    }

    public void add(Persona persona){
        personas.add(persona);
    }

    public List<Persona> getAll(){
        return personas;
    }
}
