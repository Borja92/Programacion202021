import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal {
    private JPanel pnlMain;
    private JButton button1;
    private JButton button2;
    private JPanel pnlIntercambiable;
    public Principal(){
        Panel1 panel1 = new Panel1();
        Panel2 panel2 = new Panel2();

        // Añadir los paneles obtenidos de los otros formularios

        pnlIntercambiable.add(panel1.getPanel(),"panel1");
        pnlIntercambiable.add(panel2.getPanel(),"panel2");

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout layout = (CardLayout) pnlIntercambiable.getLayout();
                layout.show(pnlIntercambiable,"panel1");
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout layout = (CardLayout) pnlIntercambiable.getLayout();
                layout.show(pnlIntercambiable,"panel2");
            }
        });
    }

    public JPanel getPanel(){
        return pnlMain;
    }
}
