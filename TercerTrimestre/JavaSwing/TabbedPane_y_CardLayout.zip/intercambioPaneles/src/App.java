import javax.swing.*;

public class App {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Intercambio");
        frame.setContentPane(new Principal().getPanel());
        frame.pack();
        frame.setVisible(true);
    }
}
