import javax.swing.*;

public class Panel2 {
    private JPanel panel2;
    private JTextField textField1;

    public JPanel getPanel(){
        return panel2;
    }
}
