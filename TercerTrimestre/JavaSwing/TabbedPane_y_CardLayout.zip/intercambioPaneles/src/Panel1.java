import javax.swing.*;

public class Panel1 {
    private JPanel panel1;
    private JButton botónDeEjemploButton;

    public JPanel getPanel(){
        return panel1;
    }
}
