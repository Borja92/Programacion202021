import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal {
    private JTabbedPane tabbedPane1;
    private JPanel panel1;

    public Principal(){
        tabbedPane1.setComponentAt(0,new Panel1().getPanel());
        tabbedPane1.setComponentAt(1,new Panel2().getPanel());
    }

    public void setMenuBar() {
        JMenuBar menu = new JMenuBar();
        JMenuItem opcion1 = new JMenu("Opción 1");
        JMenuItem opcion2 = new JMenu("Opcion 2");
        JMenuItem opcion1_1 = new JMenuItem("Opcion 1.1");
        JMenuItem opcion1_2 = new JMenuItem("Opcion 1.2");

        menu.add(opcion1);
        menu.add(opcion2);

        opcion1.add(opcion1_1);
        opcion1.add(opcion1_2);

        opcion1_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Test");
            }
        });

        JFrame frame = (JFrame) SwingUtilities.getRoot(panel1);
        frame.setJMenuBar(menu);
    }

    public JPanel getPanel(){
        return panel1;
    }


}
