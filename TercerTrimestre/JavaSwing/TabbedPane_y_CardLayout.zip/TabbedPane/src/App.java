import javax.swing.*;

public class App {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Pestañas");
        Principal principal = new Principal();
        frame.setContentPane(principal.getPanel());
        principal.setMenuBar();
        frame.pack();
        frame.setVisible(true);
    }
}
