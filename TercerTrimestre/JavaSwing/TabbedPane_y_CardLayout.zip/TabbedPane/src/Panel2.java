import javax.swing.*;

public class Panel2 {
    private JPanel panel1;
    private JTextField textField1;

    public JPanel getPanel(){
        return panel1;
    }
}
