import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Panel1 {
    private JPanel panel1;
    private JButton boton;

    public Panel1(){
        JPopupMenu menu = new JPopupMenu();
        JMenuItem opcion1 = new JMenuItem("Opción 1");
        opcion1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Opcion 1");
            }
        });

        JMenuItem opcion2 = new JMenuItem("Opcion 2");

        menu.add(opcion1);
        menu.add(opcion2);

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON3) {
                    int x = MouseInfo.getPointerInfo().getLocation().x;//boton.getLocationOnScreen().x;
                    int y = MouseInfo.getPointerInfo().getLocation().y;//boton.getLocationOnScreen().y - menu.getHeight();
                    menu.show(boton,0,0);
                    menu.setLocation(x,y);
                }
            }
        });

    }

    public JPanel getPanel(){
        return panel1;
    }
}
