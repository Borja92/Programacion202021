public interface Vista {
    public final static int HTML = 1;
    public final static int HTML_NAV = 2;
    public final static int XML = 3;
    public final static int CSV = 4;

    public void render();
}
