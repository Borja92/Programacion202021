import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySql {
    static String db = "mobant";
    static String login = "root";
    static String password = "Wend1";
    static String url = "jdbc:mysql://146.59.155.183:3306/" + db + "?useSSL=false";
    Connection conn = null;

    public Connection conexion() throws SQLException {

            conn = DriverManager.getConnection(url,login,password);
                System.out.println("Conexión ok: " + conn);
                return conn;


    }

    public void desconexion() throws SQLException {
        if (conn != null){
            conn.close();
        }
    }
}