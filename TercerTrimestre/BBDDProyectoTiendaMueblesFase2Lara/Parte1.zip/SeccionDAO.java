import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeccionDAO {
    private Connection conn;

    public SeccionDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(String seccion) throws SQLException {
        conn= new MySql().conexion();
        PreparedStatement statement = conn.prepareStatement("INSERT INTO seccion(nombre) VALUES ('" + seccion+ "')", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }
    }


    public boolean actualizar(String seccion, String nuevoNombre) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update seccion set nombre='" + nuevoNombre + "' Where nombre='" + seccion + "';").executeUpdate();
        conn.close();
        return numFilasCambiadas>0;

    }

    public String getSeccionById(int id) throws SQLException {
        conn= new MySql().conexion();
        String categoria=null;
        ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM seccion where id="+id).executeQuery();
        while(resultSet.next()){
            categoria=resultSet.getString("nombre");
        }
        conn.close();

        return categoria;

    }

    public int getId(String seccion) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM seccion where nombre= '"+seccion+"'").executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;
    }

    public boolean borrar(String seccion) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM seccion WHERE nombre = '" + seccion + "'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;
    }

    public boolean exists(String seccion) throws SQLException {
        conn = new MySql().conexion();

        int algo = 0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM seccion where nombre='" + seccion + "'").executeQuery();
        while (resultSet.next()) {
            algo = resultSet.getInt("id");
        }
        conn.close();
        if (algo != 0) {
            return true;
        } else {
            return false;
        }

    }

    public List<String> getAll() throws SQLException {
        conn = new MySql().conexion();
        List<String> secciones = new ArrayList<>();
        ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM seccion").executeQuery();

        while (resultSet.next()) {
            secciones.add(resultSet.getString("nombre"));
        }
        conn.close();
        if (secciones.size() == 0) {
            return null;}
        else { return secciones;}
    }



}
