import java.sql.*;

public class ElementoDao {
    private TipoElementoDAO tipoElementoDAO;
    private Connection conn;

    public ElementoDao(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(Elemento elemento) throws SQLException {
        conn= new MySql().conexion();
        PreparedStatement statement = conn.prepareStatement("INSERT INTO elemento(codigo,id_tipo_elemento) VALUES ('"+elemento.getCodigo()+"',"+elemento.getTipo()+")", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }
    }

    public Elemento leer(String codigo) throws SQLException {
        conn= new MySql().conexion();
        Elemento elemento = null;

        ResultSet resultSet = conn.prepareStatement("SELECT * FROM elemento where codigo='" + codigo + "'").executeQuery();
        while (resultSet.next()) {
            elemento.setCodigo(resultSet.getString("codigo"));
            elemento.setTipo(resultSet.getString("id_tipo_elemento"));
        }
        conn.close();

        return elemento;
    }

    public int getId(String codigo) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM elemento where codigo= '"+codigo+"'").executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;
    }
    public Elemento getElementoById(int id) throws SQLException {
        conn= new MySql().conexion();
        Elemento elemento=null;
        ResultSet resultSet = conn.prepareStatement("SELECT codigo FROM elemento where id="+id).executeQuery();
        while(resultSet.next()){
            elemento.setCodigo(resultSet.getString("codigo"));
            elemento.setTipo(resultSet.getString("id"));
        }
        conn.close();

        return elemento;    }

    public boolean actualizar(String codigo, String nuevoCodigo) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update elemento set codigo='" + nuevoCodigo + "' Where codigo='" + codigo + "';").executeUpdate();
        conn.close();
        return numFilasCambiadas>0;
    }

    public boolean borrar(String codigo) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM elemento WHERE codigo = '" + codigo + "'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;    }



}
