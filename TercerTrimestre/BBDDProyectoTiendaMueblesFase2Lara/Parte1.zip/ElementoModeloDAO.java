import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ElementoModeloDAO {
    private Connection conn;
    private ElementoDao elementoDao;
    private ModeloDAO modeloDAO;

    public ElementoModeloDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(String codigoElemento, String codigoModelo) throws SQLException {
        conn= new MySql().conexion();
        PreparedStatement statement = conn.prepareStatement("INSERT INTO elemento_modelo(id_elemento,id_modelo) VALUES ('"+codigoElemento+"','"+codigoModelo+"')", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }    }

    public int getId(String codigoElemento, String codigoModelo) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM elemento_modelo where id_elemento="+codigoElemento+" && id_modelo="+codigoModelo).executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;
    }

    public boolean actualizarModelo(String codigoElemento, String codigoModelo, String codigoNuevoModelo) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update elemento_modelo set id_modelo='" + codigoNuevoModelo + "' Where id_modelo=" + codigoModelo + " && id_elemento="+codigoElemento).executeUpdate();
        conn.close();
        return numFilasCambiadas>0;
    }


    public List<Elemento> getElementosByCodigoModelo(String codigoModelo) throws SQLException {
        conn = new MySql().conexion();
        List<Elemento> elemento = new ArrayList<>();
        Elemento elemento1 = null;
        ResultSet resultSet = conn.prepareStatement("SELECT id_elemento FROM elemento where id_modelo=" + codigoModelo).executeQuery();
        while (resultSet.next()) {
            elemento1.setCodigo(resultSet.getString("codigo"));
            elemento1.setTipo(resultSet.getString("id"));
            elemento.add(elemento1);
        }
        conn.close();
        return elemento;
    }

    public boolean borrar(String codigoElemento, String codigoModelo) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM elemento WHERE (select id from elemento) = '" + codigoElemento + "' && (select id from modelo)='"+codigoModelo+"'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;    }
    }

