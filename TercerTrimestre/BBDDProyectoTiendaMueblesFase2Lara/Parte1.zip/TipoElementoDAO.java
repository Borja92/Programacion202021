import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoElementoDAO {
    private Connection conn;

    public TipoElementoDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(String nombre) throws SQLException {
        conn = new MySql().conexion();

        PreparedStatement statement = conn.prepareStatement("INSERT INTO tipo_elemento(nombre) VALUES ('"+nombre+"')", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }
    }

    public String getTipoElementoById(int id) throws SQLException {
        conn= new MySql().conexion();
        String tipoElemento=null;
        ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM tipo_elemento where id="+id).executeQuery();
        while(resultSet.next()){
            tipoElemento=resultSet.getString("nombre");
        }
        conn.close();

        return tipoElemento;

    }

    public int getId(String tipoElemento) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM tipo_elemento where nombre= '"+tipoElemento+"'").executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;
    }

    public boolean actualizar(String tipoElemento, String nuevoNombre) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update tipo_elemento set nombre='" + nuevoNombre + "' Where nombre='" + tipoElemento + "';").executeUpdate();
        conn.close();
        return numFilasCambiadas>0;
    }

    public List<String> getAll() throws SQLException {
        conn = new MySql().conexion();
        List<String> tipo_elemento = new ArrayList<>();
        ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM tipo_elemento").executeQuery();

        while (resultSet.next()) {
            tipo_elemento.add(resultSet.getString("nombre"));
        }
        conn.close();
        if (tipo_elemento.size() == 0) {
            return null;}
        else { return tipo_elemento;}
    }

    public boolean exists(String tipoElemento) throws SQLException {
        conn = new MySql().conexion();

        int algo = 0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM tipo_elemento where nombre='" + tipoElemento + "'").executeQuery();
        while (resultSet.next()) {
            algo = resultSet.getInt("id");
        }
        conn.close();
        if (algo != 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean borrar(String tipoElemento) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM tipo_elemento WHERE nombre = '" + tipoElemento + "'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;
    }

}
