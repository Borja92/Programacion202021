import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ModeloDAO {
    private Connection conn;
    private SeccionDAO seccionDAO;
    private CategoriaDao categoriaDao;

    public ModeloDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(Modelo modelo) throws SQLException {
        conn= new MySql().conexion();
        PreparedStatement statement = conn.prepareStatement("INSERT INTO modelo(codigo,id_seccion,id_categoria) VALUES ('"+modelo.getCodigo()+"',"+modelo.getSeccion()+","+modelo.getCategoria()+")", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }
    }

    public Modelo leer(String codigo) throws SQLException {
        conn= new MySql().conexion();
        Modelo modelo = null;

        ResultSet resultSet = conn.prepareStatement("SELECT * FROM modelo where codigo='" + codigo + "'").executeQuery();
        while (resultSet.next()) {
            modelo.setCodigo(resultSet.getString("codigo"));
            modelo.setSeccion(resultSet.getString("id_seccion"));
            modelo.setCategoria(resultSet.getString("id_categoria"));
        }
        conn.close();

        return modelo;
    }

    public int getId(String codigo) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM modelo where codigo= '"+codigo+"'").executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;

    }

    public boolean actualizar(String codigo, String nuevoCodigo) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update modelo set codigo='" + nuevoCodigo + "' Where codigo='" + codigo + "';").executeUpdate();
        conn.close();
        return numFilasCambiadas>0;
    }


    public List<String> getCodigosModelos() throws SQLException {
        conn= new MySql().conexion();
        List<String> codigoModelos = new ArrayList<>();
        ResultSet resultSet = conn.prepareStatement("SELECT codigo FROM modelo").executeQuery();

        while (resultSet.next()) {
            codigoModelos.add(resultSet.getString("codigo"));
        }
        conn.close();

        if (codigoModelos.size() == 0) {
            return null;}
        else {
            return codigoModelos;}



    }

    public List<String> getCodigosModelosByCategoria(String categoria) throws SQLException {
        conn= new MySql().conexion();
        List<String> codigoModelosPorCategorias = new ArrayList<>();
        ResultSet resultSet = conn.prepareStatement("SELECT codigo FROM modelo where id_categoria="+categoria+")").executeQuery();

        while (resultSet.next()) {
            codigoModelosPorCategorias.add(resultSet.getString("codigo"));
        }
        conn.close();

        if (codigoModelosPorCategorias.size() == 0) {
            return null;}
        else {
            return codigoModelosPorCategorias;}



    }

    public List<String> getCodigosModelosBySeccion(String seccion) throws SQLException {
        conn= new MySql().conexion();
        List<String> codigoModelosPorCategorias = new ArrayList<>();
        ResultSet resultSet = conn.prepareStatement("SELECT codigo FROM modelo where id_seccion="+seccion+")").executeQuery();

        while (resultSet.next()) {
            codigoModelosPorCategorias.add(resultSet.getString("codigo"));
        }
        conn.close();

        if (codigoModelosPorCategorias.size() == 0) {
            return null;}
        else {
            return codigoModelosPorCategorias;}




    }
    public boolean borrar(String codigo) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM modelo WHERE codigo = '" + codigo + "'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;
    }

}
