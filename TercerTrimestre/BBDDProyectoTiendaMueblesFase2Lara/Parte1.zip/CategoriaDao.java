import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDao {
    private Connection conn;

    public CategoriaDao(Connection conn) {
        this.conn = conn;
    }

    public boolean crear(String categoria) throws SQLException {
    conn= new MySql().conexion();
        PreparedStatement statement = conn.prepareStatement("INSERT INTO categoria(nombre) VALUES ('" + categoria+ "')", Statement.RETURN_GENERATED_KEYS);
        statement.executeUpdate();
        ResultSet resultSet = statement.getGeneratedKeys();
        if (resultSet.next()){
            conn.close();
            return true;
        }
        else{
            conn.close();
            return false;
        }
    }


    public boolean actualizar(String categoria, String nuevoNombre) throws SQLException {
        conn= new MySql().conexion();
        int numFilasCambiadas = conn.prepareStatement("Update categoria set nombre='" + nuevoNombre + "' Where nombre='" + categoria + "';").executeUpdate();
        conn.close();
            return numFilasCambiadas>0;

        }



    public String getCategoriaById(int id) throws SQLException {
        conn= new MySql().conexion();
       String categoria=null;
        ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM categoria where id="+id).executeQuery();
        while(resultSet.next()){
            categoria=resultSet.getString("nombre");
        }
        conn.close();

            return categoria;

    }

    public int getId(String categoria) throws SQLException {
        conn= new MySql().conexion();
        int id=0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM categoria where nombre= '"+categoria+"'").executeQuery();
        while(resultSet.next()){
            id=resultSet.getInt("id");
        }
        conn.close();

        return id;
    }

    public boolean borrar(String categoria) throws SQLException {
        conn = new MySql().conexion();
        int numFilasBorradas = conn.prepareStatement("DELETE FROM categoria WHERE nombre = '" + categoria + "'").executeUpdate();
        conn.close();
        return numFilasBorradas > 0;
    }

    public boolean exists(String categoria) throws SQLException {
        conn = new MySql().conexion();

        int algo = 0;
        ResultSet resultSet = conn.prepareStatement("SELECT id FROM categoria where nombre='" + categoria + "'").executeQuery();
        while (resultSet.next()) {
            algo = resultSet.getInt("id");
        }
        conn.close();
        if (algo != 0) {
            return true;
        } else {
            return false;
        }
    }

        public List<String> getAll() throws SQLException {
        conn = new MySql().conexion();
        List<String> categorias = new ArrayList<>();
            ResultSet resultSet = conn.prepareStatement("SELECT nombre FROM categoria").executeQuery();

            while (resultSet.next()) {
                categorias.add(resultSet.getString("nombre"));
            }
            conn.close();
            if (categorias.size() == 0) {
                return null;}
            else { return categorias;}


        }






}
