package LSP;

public interface Vehiculo {
    public void volar();
    public void circular();
    public void navegar();
}
