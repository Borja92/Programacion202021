package OCP;

public class Resta {
    public int operar(int a, int b){
        return a - b;
    }
}
