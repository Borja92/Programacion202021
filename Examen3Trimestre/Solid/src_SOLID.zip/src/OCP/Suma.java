package OCP;

public class Suma {
    public int operar(int a, int b){
        return a + b;
    }
}
