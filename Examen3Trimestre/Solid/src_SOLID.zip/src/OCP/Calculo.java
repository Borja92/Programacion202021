package OCP;

import java.util.Scanner;

public class Calculo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.print("1. OCP.Suma\n2. OCP.Resta\nOpcion: ");
        int opcion = sc.nextInt();

        System.out.print("Número (operando a): ");
        int a = sc.nextInt();

        System.out.print("Número (operando b): ");
        int b = sc.nextInt();

        int resultado = 0;

        // APLICA OCP DESDE AQUÍ

        if (opcion == 1) {
            Suma suma = new Suma();
            resultado = suma.operar(a,b);
        } if (opcion == 2) {
            Resta resta = new Resta();
            resultado = resta.operar(a, b);
        }

        // APLICA OCP HASTA AQUÍ

        System.out.println("El resultado es : " + resultado);
    }
}
