package DIP;

public class Gallina implements AnimalDeGranja {
    @Override
    public String habla() {
        return "Cococo";
    }
}
