package DIP;

public interface AnimalDeGranja {
    public final static int VACA = 1;
    public final static int GALLINA = 2;
    public final static int CERDO = 3;

    public String habla();
}
