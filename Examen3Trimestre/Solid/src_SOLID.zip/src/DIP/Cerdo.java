package DIP;

public class Cerdo implements AnimalDeGranja {
    @Override
    public String habla() {
        return "Oink";
    }
}
