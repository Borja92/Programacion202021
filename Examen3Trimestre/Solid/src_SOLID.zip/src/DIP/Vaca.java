package DIP;

public class Vaca implements AnimalDeGranja {
    @Override
    public String habla() {
        return "Muuu";
    }
}
