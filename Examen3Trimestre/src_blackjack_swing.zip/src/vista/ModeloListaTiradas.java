package vista;

import blackjack.Jugador;

import javax.swing.*;

public class ModeloListaTiradas extends AbstractListModel<Integer> {
    private Jugador jugador;

    public ModeloListaTiradas(Jugador jugador){
        this.jugador = jugador;
    }

    @Override
    public int getSize() {
        return -1;
    }

    @Override
    public Integer getElementAt(int index) {
        return -1;
    }
}
