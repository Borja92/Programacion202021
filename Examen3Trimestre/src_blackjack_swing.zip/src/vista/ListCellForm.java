package vista;

import javax.swing.*;

public class ListCellForm {
    private JPanel pnlMain;
    private JLabel lblNumeroTirada;
    private JLabel lblNumeroObtenido;
}
