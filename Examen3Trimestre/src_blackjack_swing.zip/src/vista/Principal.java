package vista;

import blackjack.Jugador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class Principal {
    private JPanel pnlMain;

    private JPanel pnlNombreJugador1;
    private JPanel pnlNombreJugador2;

    private JList lstJugador1;
    private JList lstJugador2;

    private JButton btnNuevaPartida;

    private JLabel lblJugador1;
    private JLabel lblJugador2;

    private JButton btnCambiarNombreJugador1;
    private JButton btnCambiarNombreJugador2;

    private JLabel lblPtosJugador1;
    private JLabel lblPtosJugador2;

    private JButton btnTiradaJugador1;
    private JButton btnTiradaJugador2;

    private JTextField txtGanador;

    private ModeloListaTiradas modeloLista1, modeloLista2;
    private Jugador jugador1, jugador2;

    public Principal(Jugador jugador1, Jugador jugador2){
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        modeloLista1 = new ModeloListaTiradas(jugador1);
        modeloLista2 = new ModeloListaTiradas(jugador2);
    }

    public Container getPanel() {
        return pnlMain;
    }
}
